using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;
using Pinvoke;

namespace TestAvicap32
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeDevicesList();
        }

        private void InitializeDevicesList()
        {
            splitContainer1.Panel1.Enabled = true;
            splitContainer1.Panel2.Enabled = false;

            foreach (CaptureDevice device in CaptureDevice.GetDevices())
            {
                cboDevices.Items.Add(device);
            }

            if (cboDevices.Items.Count > 0)
            {
                cboDevices.SelectedIndex = 0;
            }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            int index = cboDevices.SelectedIndex;
            if (index != -1)
            {
                splitContainer1.Panel1.Enabled = false;
                splitContainer1.Panel2.Enabled = true;
                ((CaptureDevice)cboDevices.SelectedItem).Attach(pbImage);
            }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            splitContainer1.Panel1.Enabled = true;
            splitContainer1.Panel2.Enabled = false;
            ((CaptureDevice)cboDevices.SelectedItem).Detach();
        }

        private void btnSnapshot_Click(object sender, EventArgs e)
        {
            try
            {
                Image image = ((CaptureDevice)cboDevices.SelectedItem).Capture();
                image.Save(@"c:\capture.png", ImageFormat.Png);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
    }
}